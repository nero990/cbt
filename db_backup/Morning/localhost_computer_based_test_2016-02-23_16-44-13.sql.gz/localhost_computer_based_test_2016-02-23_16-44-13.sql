-- Auto Backup for MySQL Professional Edition 2.1
--
-- Host: localhost
--
-- MySQL Server Version: 5.6.12-log
--
-- 2016-02-23 16:44:13
--
-- ------------------------------------------------------

SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS;
SET @OLD_CHARACTER_SET_CONNECTION=@@CHARACTER_SET_CONNECTION;
SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS;
SET UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES=@@SQL_NOTES;
SET SQL_NOTES=0;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_classes`;
CREATE TABLE IF NOT EXISTS `cbt_classes` (  `class_id` int(11) NOT NULL AUTO_INCREMENT,  `_class` varchar(7) NOT NULL,  PRIMARY KEY (`class_id`)) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_classes` DISABLE KEYS;
LOCK TABLES `cbt_classes` WRITE;
INSERT INTO `cbt_classes`(`class_id`,`_class`) VALUES (1,'JSS I'),(2,'JSS II'),(3,'JSS III'),(4,'SSS I'),(5,'SSS II'),(6,'SSS III');
UNLOCK TABLES;
ALTER TABLE `cbt_classes` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_questions`;
CREATE TABLE IF NOT EXISTS `cbt_questions` (  `quest_id` int(11) NOT NULL AUTO_INCREMENT,  `subj_id` int(11) NOT NULL,  `class_id` int(11) NOT NULL,  `question` text NOT NULL,  `a` text NOT NULL,  `b` text NOT NULL,  `c` text NOT NULL,  `d` text NOT NULL,  `answer` varchar(2) NOT NULL,  PRIMARY KEY (`quest_id`),  KEY `course_id` (`subj_id`),  KEY `class_id` (`class_id`),  CONSTRAINT `cbt_questions_ibfk_1` FOREIGN KEY (`subj_id`) REFERENCES `cbt_subjects` (`subj_id`),  CONSTRAINT `cbt_questions_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `cbt_classes` (`class_id`)) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_questions` DISABLE KEYS;
LOCK TABLES `cbt_questions` WRITE;
INSERT INTO `cbt_questions`(`quest_id`,`subj_id`,`class_id`,`question`,`a`,`b`,`c`,`d`,`answer`) VALUES (8,3,6,'RAM stands for _______','Read Access Memory','Random Access Memory','Radio Acccess Memory','Royal Abassador Memory','B'),(10,10,3,'Feeling or opinion one has about something is known as __________________','Attibutes','Attitde','Tolerance','Transparency','B'),(11,10,3,'Reward and importance of right attitude to work is that __________________','It leads to lower productivity','It leads to inefficiency','It leads to higher productivity','None of the above','C'),(12,10,3,'Manner one conducts itself is known as __________','Behaviour','Disregard','Integrity','Tolerance','A'),(14,10,3,'The headcount of people living in a geographical location is known as ___________','Population death','Population Cencus','Population birth','Population migrate','B'),(15,10,3,'All these are importance of population census except __________','It is a tool for corruption','It is a tool for national planning','It assist the government in formulating policies','It assist in distribution and allocation of resources','A'),(16,10,3,'Right to vote and be voted for is known as','Policatical Rights','Social Right','Legal Right','Cultural Right','A'),(17,10,3,'The right of Nigerian Citizens are normally spelt out under the ___________','Superstitious belief','Constitution','All of the above','None of the above','B'),(18,10,3,'For population census figure to be acceptable in Nigeria, it must be conducted in a way and manner that will reflect the following except _____________','It must be free and fair','There must be adequate and enough funder','It must be conducted during raining season','There must be enough and adequate planning years','C'),(19,10,3,'No man is above the law is one of the principles of _____________','Rule of labour','Rule of man','Rule of law','None of the above','C');
INSERT INTO `cbt_questions`(`quest_id`,`subj_id`,`class_id`,`question`,`a`,`b`,`c`,`d`,`answer`) VALUES (20,2,2,'What\'s the past tense of \"GO\"?','Went','Gone','Going','Go','A'),(21,2,2,'I have ___________ him his book','give','given','gave','giving','B'),(22,3,1,'What is the meaning of DVD?','Digital Versatile Disk','Digital Version Disk','Digital Versal Disk','Digital Vera Disk','A'),(23,12,3,'Which chapter of the holy Qur’an is compulsory recited in Muslim prayer?','Suratul Fatiha','Suratul ikhilas','Suratul Falaq','Ramadan','A'),(24,12,3,'Salatul – Trawih is performed during the month of','Rajab','Ramadan','Shawal','Muaram','B'),(25,1,4,'Find the simple interest on # 400 for 2 years at 8 %','# 64','# 45','# 33','#54','A'),(26,1,4,'Solve for x in the equation 2 (x +1) = x + 4','2','3','4','5','A'),(27,1,4,'. If a certain number is added to 13 to give 30 find the number','16','17','18','19','B'),(28,1,4,'Express 250000 in standard form','25.3 X 10r5','2.5 X 10r5','2.5 X 10r7','2.5 X 10r7','B'),(29,1,4,'Convert 31ten to a number in base 2','110111two','100111two','11111two','110011two','C');
INSERT INTO `cbt_questions`(`quest_id`,`subj_id`,`class_id`,`question`,`a`,`b`,`c`,`d`,`answer`) VALUES (30,1,4,'If (-3) ÷ (-24) = y, then Y is ……………','23','35','1/8','34','C'),(31,1,4,'Convert 101010two to a number in base ten','42','33','72','23','A'),(32,1,4,'Simplify 8m X 7n','56mn','56nnm','35mmn','35m2n','A'),(33,1,4,'Express 35% as a fraction','3/5','7/20','4/5','4/9','B'),(34,1,4,'Which sum of one of the following is a prime number','3+19','3 + 20','3 + 7','3 + 5','B'),(35,1,4,'What is the range of the following number 40, 45, 65, 36, 23, 15?','23','50','23','22','B'),(36,1,4,'Simplify -7-(-16) -3','5','-6','6','3','C'),(37,1,4,'When a number is divided by 6, the result is 8. Find the number.','48','33','46','24','A'),(38,1,4,'Solve this equation 5x + 5 = 26 + 2x','7','8','9','10','A'),(39,1,4,'Express 68% as a fraction in its lowest term','3/5','17/25','32','12','B');
INSERT INTO `cbt_questions`(`quest_id`,`subj_id`,`class_id`,`question`,`a`,`b`,`c`,`d`,`answer`) VALUES (40,1,4,'Simplify -3(-4 + 2)','13','61','6','27','C'),(41,1,4,'Which is the greatest of these negative integers? -20, -25, -30, -2, -7','-2','-25','-30','-7','A'),(42,1,4,'Find the coefficient of X in the expansion of (X – 3) (X -5)','10','-8','2','4','B'),(43,1,4,'Add together 425 and 765','2235','2325','3235','3322','A'),(44,1,4,'A Woman bought 10 oranges at the rate of #50 per one orange and sold them at the rate  \r\n     Of # 70 per one. Calculate her profit. (a) 200 (b) 300 (c) 420','200','300','420','343','A'),(45,1,5,'If Ө is one of the angles of right angle triangle of tan Ө = ¾ find cos Ө','4/5','3/4','5','2','A'),(46,1,5,'A boy cycles a distance of 12km in 5 hours Calculate his speed in kilometers per hour.','2.4km/h','60km/h','125km/h','165km/h','A'),(47,1,5,'Find the value of 2h + 3z when h = 2 and Z = 3','13','17','9','4','A'),(48,1,5,'When 5 is added to twice a number the result is 15, what is the number','3','12','20','5','D'),(49,1,5,'How much simple interest does # 600 yield in 3 years at 7% per annum','126','142','132','321','A');
INSERT INTO `cbt_questions`(`quest_id`,`subj_id`,`class_id`,`question`,`a`,`b`,`c`,`d`,`answer`) VALUES (50,1,5,'The next term of the sequence 1, 3, 9, 27, 81……','432','721','243','322','C'),(51,1,5,'Express 0.0089 in standard form','8.9 X 10 r -3','8.9 X 10 r -2','89.3 X 10 r 5','893 X 10 r 5','A'),(52,1,5,'Solve the equation 2n + 5 = 7','2','1','2','3','B'),(53,1,5,'Which sum of the following is a prime number','3 + 7','3 + 20','3 + 19','3 + 3','B'),(54,1,5,'What is the range of the following numbers 40, 45, 65, 36, 23, 15?','50','54','45','22','A'),(55,1,5,'How many months are these in 52 weeks?','52  months','13 months','23 months','50  months','B'),(56,1,5,'When a number is divided by 6, then result is 8. Find the number','48','73','23','32','A'),(57,1,5,'Calculate the Principal which attracts an interest of # 16 in 2 years at 4% per annum.','200','150','100','230','A'),(58,1,5,'Solve this equation 5x + 5 =26 + 2x','6','8','9','7','D'),(59,1,5,'If 17  is subtracted from a certain number and then the result is divided by 5, and the final answer is 3. What is the original number','43','32','21','32','B');
INSERT INTO `cbt_questions`(`quest_id`,`subj_id`,`class_id`,`question`,`a`,`b`,`c`,`d`,`answer`) VALUES (60,1,5,'Simplify 11P + 3q – 5P – 2q','6q – p','6q + q','6q – q','6q – 6','B'),(61,1,5,'Express 4/5 as a decimal (a) 4.8 (b) 0.3 (c) 0.8','4.8','0.3','0.8','0.4','C'),(62,1,5,'Simplify (4x – 5y) + 11y','4x – 3y','10y','4x + 6y','4x + 4y','C'),(63,1,5,'45% of a class of 40 pupils are girls. How many are boys? (a) 22 (b) 34 (c) 23','22','34','23','12','A'),(64,1,5,'A plot of land is offered for sale at 350,000, with a provision of 20% discount. What is the cash price','280000','235000','120000','122000','A');
UNLOCK TABLES;
ALTER TABLE `cbt_questions` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_results`;
CREATE TABLE IF NOT EXISTS `cbt_results` (  `result_id` int(11) NOT NULL AUTO_INCREMENT,  `student_id` int(11) NOT NULL,  `subj_id` int(11) NOT NULL,  `class_id` int(11) NOT NULL,  `total_question` int(11) NOT NULL,  `answered_quest` int(11) NOT NULL,  `total_valid_ans` int(11) NOT NULL,  `total_wrong_ans` int(11) NOT NULL,  `unanswered` int(11) NOT NULL,  `score` decimal(10,2) NOT NULL,  `test_date` date DEFAULT NULL,  PRIMARY KEY (`result_id`),  KEY `cand_course_id` (`student_id`),  KEY `subj_id` (`subj_id`,`class_id`),  KEY `class_id` (`class_id`),  CONSTRAINT `cbt_results_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `cbt_students` (`student_id`),  CONSTRAINT `cbt_results_ibfk_2` FOREIGN KEY (`subj_id`) REFERENCES `cbt_subjects` (`subj_id`),  CONSTRAINT `cbt_results_ibfk_3` FOREIGN KEY (`class_id`) REFERENCES `cbt_classes` (`class_id`)) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_results` DISABLE KEYS;
LOCK TABLES `cbt_results` WRITE;
INSERT INTO `cbt_results`(`result_id`,`student_id`,`subj_id`,`class_id`,`total_question`,`answered_quest`,`total_valid_ans`,`total_wrong_ans`,`unanswered`,`score`,`test_date`) VALUES (17,4,3,6,2,0,0,1,0,'0.00','2016-02-23'),(29,1,2,2,5,5,2,3,0,'40.00','2016-02-23'),(35,6,3,1,1,1,1,0,0,'100.00','2016-02-23'),(36,5,10,3,9,8,1,7,1,'11.11','2016-02-23'),(38,5,12,3,2,2,1,1,0,'50.00','2016-02-23'),(45,2,1,4,20,19,11,8,1,'55.00','2016-02-23'),(46,11,1,4,20,19,6,13,1,'30.00','2016-02-23'),(47,1,1,4,20,20,7,13,0,'35.00','2016-02-23'),(48,7,1,4,20,19,9,10,1,'45.00','2016-02-23'),(49,9,1,4,20,19,14,5,1,'70.00','2016-02-23');
INSERT INTO `cbt_results`(`result_id`,`student_id`,`subj_id`,`class_id`,`total_question`,`answered_quest`,`total_valid_ans`,`total_wrong_ans`,`unanswered`,`score`,`test_date`) VALUES (50,5,1,4,20,20,9,11,0,'45.00','2016-02-23'),(54,3,1,4,20,20,10,10,0,'50.00','2016-02-23'),(55,13,1,4,20,20,12,8,0,'60.00','2016-02-23'),(56,6,1,4,20,19,10,9,1,'50.00','2016-02-23'),(57,14,1,4,20,19,10,9,1,'50.00','2016-02-23'),(58,45,1,5,20,19,9,10,1,'45.00','2016-02-23'),(59,50,1,5,20,20,12,8,0,'60.00','2016-02-23'),(62,30,1,5,20,0,0,0,20,'0.00','2016-02-23'),(68,10,1,4,20,19,9,10,1,'55.00','2016-02-23'),(74,12,1,4,20,1,0,1,19,'0.00','2016-02-23');
UNLOCK TABLES;
ALTER TABLE `cbt_results` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_students`;
CREATE TABLE IF NOT EXISTS `cbt_students` (  `student_id` int(11) NOT NULL AUTO_INCREMENT,  `surname` varchar(40) NOT NULL,  `other_names` varchar(80) NOT NULL,  `class_id` int(11) NOT NULL,  `reg_no` varchar(10) NOT NULL,  `state` tinyint(4) NOT NULL,  `subj_id` int(11) DEFAULT NULL,  `duration` time DEFAULT NULL,  `start_time` datetime DEFAULT NULL,  `stop_time` datetime DEFAULT NULL,  `session_val` varchar(40) DEFAULT NULL,  PRIMARY KEY (`student_id`),  KEY `class_id` (`class_id`),  KEY `subj_id` (`subj_id`),  CONSTRAINT `cbt_students_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `cbt_classes` (`class_id`),  CONSTRAINT `cbt_students_ibfk_2` FOREIGN KEY (`subj_id`) REFERENCES `cbt_subjects` (`subj_id`)) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_students` DISABLE KEYS;
LOCK TABLES `cbt_students` WRITE;
INSERT INTO `cbt_students`(`student_id`,`surname`,`other_names`,`class_id`,`reg_no`,`state`,`subj_id`,`duration`,`start_time`,`stop_time`,`session_val`) VALUES (1,'OGUNLADE','AKEEM',4,'58017153IH',0,NULL,NULL,NULL,NULL,NULL),(2,'AKANO','OKIKI',4,'57881357VA',0,NULL,NULL,NULL,NULL,NULL),(3,'ADENIYI','FLORENCE',4,'55786311XE',0,NULL,NULL,NULL,NULL,NULL),(4,'ALABI','MUYIWA',5,'51419051ZQ',0,NULL,NULL,NULL,NULL,NULL),(5,'OYEGBOLA','WASILAT',4,'69858577RH',0,NULL,NULL,NULL,NULL,NULL),(6,'AJIBOYE','SULEMAN',4,'61560857UZ',0,NULL,NULL,NULL,NULL,NULL),(7,'AKANO','ABIODUN',4,'65290468EQ',0,NULL,NULL,NULL,NULL,NULL),(8,'OLORODE','NURUDEEN',5,'65744437OM',0,NULL,NULL,NULL,NULL,NULL),(9,'SALAHUDEEN','TESLIM',4,'66691268XK',0,NULL,NULL,NULL,NULL,NULL),(10,'ABOLARIN','JUMAIN',4,'62615697IL',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cbt_students`(`student_id`,`surname`,`other_names`,`class_id`,`reg_no`,`state`,`subj_id`,`duration`,`start_time`,`stop_time`,`session_val`) VALUES (11,'ALABI','TEMITOPE',4,'69695034VP',0,NULL,NULL,NULL,NULL,NULL),(12,'JAMES','FRIDAY',4,'64498029SC',0,NULL,NULL,NULL,NULL,NULL),(13,'ABOYEJI','EYITAYO',4,'62994617XU',0,NULL,NULL,NULL,NULL,NULL),(14,'ABDUL SALAM','MUSILIU',4,'66517936ZD',0,NULL,NULL,NULL,NULL,NULL),(15,'ALABI','RUKAYAT',5,'66001469KT',0,NULL,NULL,NULL,NULL,NULL),(16,'OLADIMEJI','OPEYEMI',5,'63672063NP',0,NULL,NULL,NULL,NULL,NULL),(17,'OLADIMEJI','AMINAT',5,'69747125IP',0,NULL,NULL,NULL,NULL,NULL),(18,'SULEMAN','FATAHI',5,'65345961DC',0,NULL,NULL,NULL,NULL,NULL),(19,'AYOADE','SODIQ',5,'65941127BU',0,NULL,NULL,NULL,NULL,NULL),(20,'OYINLOYE','IDOWU',5,'65810268JL',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cbt_students`(`student_id`,`surname`,`other_names`,`class_id`,`reg_no`,`state`,`subj_id`,`duration`,`start_time`,`stop_time`,`session_val`) VALUES (21,'JIMOH','KEHINDE',5,'69019093MF',0,NULL,NULL,NULL,NULL,NULL),(22,'JIMOH','BALIKIS',5,'67301705OY',0,NULL,NULL,NULL,NULL,NULL),(23,'OLATUNJI','SAMUEL',5,'64230940RZ',0,NULL,NULL,NULL,NULL,NULL),(24,'OLAOYE','MUSTAPHA',5,'65804879EK',0,NULL,NULL,NULL,NULL,NULL),(25,'ABDUL SALAM','SODIQ',5,'64594175OX',0,NULL,NULL,NULL,NULL,NULL),(26,'AYOOLA','OMOBOLA',5,'61916758VY',0,NULL,NULL,NULL,NULL,NULL),(27,'OLATUNJI','KAFAYAT',5,'69857659LD',0,NULL,NULL,NULL,NULL,NULL),(28,'ADEYEMI','SUNDAY',5,'61517282KA',0,NULL,NULL,NULL,NULL,NULL),(29,'OLAOYE','AYODEJI',5,'67524899KJ',0,NULL,NULL,NULL,NULL,NULL),(30,'ADEDOYIN','RIDWAN',5,'61626892SQ',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cbt_students`(`student_id`,`surname`,`other_names`,`class_id`,`reg_no`,`state`,`subj_id`,`duration`,`start_time`,`stop_time`,`session_val`) VALUES (31,'FOLORUNSHO','BALIKIS',5,'68708105BM',0,NULL,NULL,NULL,NULL,NULL),(32,'AKANGBE','JELILAT',5,'69689992GY',0,NULL,NULL,NULL,NULL,NULL),(33,'OLADIMEJI','HISLAMIAT',5,'62768939EJ',0,NULL,NULL,NULL,NULL,NULL),(34,'YAHAYAH','LATEEFAT',5,'68162325JY',0,NULL,NULL,NULL,NULL,NULL),(35,'MUHAMMED','SHUKURAT',5,'65967060GD',0,NULL,NULL,NULL,NULL,NULL),(36,'IBRAHEEM','SHUKURAT',5,'64103182PA',0,NULL,NULL,NULL,NULL,NULL),(37,'NDASULE','NINMA',5,'64708595NU',0,NULL,NULL,NULL,NULL,NULL),(38,'OBATULA','ZULIYAT',5,'64837842PD',0,NULL,NULL,NULL,NULL,NULL),(39,'SAMUEL','TOSIN',5,'63481336MY',0,NULL,NULL,NULL,NULL,NULL),(40,'RAHAMAN','RAHAMAT',5,'68025118OS',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cbt_students`(`student_id`,`surname`,`other_names`,`class_id`,`reg_no`,`state`,`subj_id`,`duration`,`start_time`,`stop_time`,`session_val`) VALUES (41,'AJIDE','DAMILOLA',5,'68019958MQ',0,NULL,NULL,NULL,NULL,NULL),(42,'JIMOH','LATEEFAT',5,'64696129IV',0,NULL,NULL,NULL,NULL,NULL),(43,'OWOLABI','HANIFAT',5,'62491380TH',0,NULL,NULL,NULL,NULL,NULL),(44,'AWOLOLA','PELUMI',5,'64403783WS',0,NULL,NULL,NULL,NULL,NULL),(45,'ADEOYE','MARY',5,'69087566SF',0,NULL,NULL,NULL,NULL,NULL),(46,'ADEYEMI','RONKE',5,'61524718DA',0,NULL,NULL,NULL,NULL,NULL),(47,'OGUNLADE','T  JAMIU',5,'64820383PN',0,NULL,NULL,NULL,NULL,NULL),(48,'OGUNLADE','L  JAMIU',5,'69170966YK',0,NULL,NULL,NULL,NULL,NULL),(49,'SALMAN','JAMIU',5,'65991590DK',0,NULL,NULL,NULL,NULL,NULL),(50,'ADEYEMI','RICHARD',5,'63253486DJ',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cbt_students`(`student_id`,`surname`,`other_names`,`class_id`,`reg_no`,`state`,`subj_id`,`duration`,`start_time`,`stop_time`,`session_val`) VALUES (51,'AWONUSI','HALIMAT',5,'62944906QT',0,NULL,NULL,NULL,NULL,NULL),(52,'LAWAL','ADETUTU',5,'61556870FW',0,NULL,NULL,NULL,NULL,NULL),(53,'OLAREWAJU','TOHEEBAT',5,'69315901MK',0,NULL,NULL,NULL,NULL,NULL),(54,'OMOLE','EMMANUEL',5,'67802386KY',0,NULL,NULL,NULL,NULL,NULL);
UNLOCK TABLES;
ALTER TABLE `cbt_students` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_students_answers`;
CREATE TABLE IF NOT EXISTS `cbt_students_answers` (  `student_ans_id` int(11) NOT NULL AUTO_INCREMENT,  `student_id` int(11) NOT NULL,  `subj_id` int(11) NOT NULL,  `class_id` int(11) NOT NULL,  `quest_id` int(11) NOT NULL,  `student_ans` varchar(2) NOT NULL,  `remark` tinyint(1) NOT NULL,  PRIMARY KEY (`student_ans_id`),  KEY `cand_course_id` (`subj_id`),  KEY `question_id` (`quest_id`),  KEY `student_id` (`student_id`),  KEY `class_id` (`class_id`),  CONSTRAINT `cbt_students_answers_ibfk_2` FOREIGN KEY (`quest_id`) REFERENCES `cbt_questions` (`quest_id`),  CONSTRAINT `cbt_students_answers_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `cbt_students` (`student_id`),  CONSTRAINT `cbt_students_answers_ibfk_4` FOREIGN KEY (`class_id`) REFERENCES `cbt_classes` (`class_id`),  CONSTRAINT `cbt_students_answers_ibfk_5` FOREIGN KEY (`subj_id`) REFERENCES `cbt_subjects` (`subj_id`)) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_students_answers` DISABLE KEYS;
LOCK TABLES `cbt_students_answers` WRITE;
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (67,1,1,4,25,'B',0),(68,1,1,4,26,'C',0),(69,1,1,4,27,'B',1),(70,1,1,4,28,'A',0),(71,1,1,4,29,'C',1),(72,1,1,4,30,'B',0),(73,1,1,4,31,'C',0),(74,1,1,4,32,'A',1),(75,1,1,4,33,'A',0),(76,1,1,4,34,'B',1);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (77,1,1,4,35,'C',0),(78,1,1,4,36,'B',0),(79,1,1,4,37,'A',1),(80,1,1,4,38,'D',0),(81,1,1,4,39,'B',1),(82,1,1,4,40,'C',1),(83,1,1,4,41,'B',0),(84,1,1,4,42,'C',0),(85,1,1,4,43,'C',0),(86,1,1,4,44,'B',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (87,7,1,4,25,'C',0),(88,7,1,4,26,'A',1),(89,7,1,4,27,'B',1),(90,7,1,4,28,'B',1),(91,7,1,4,29,'D',0),(92,7,1,4,30,'C',1),(93,7,1,4,31,'B',0),(94,7,1,4,32,'D',0),(95,7,1,4,33,'A',0),(96,7,1,4,34,'C',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (97,7,1,4,35,'A',0),(98,7,1,4,36,'C',1),(99,7,1,4,37,'A',1),(100,7,1,4,38,'A',1),(101,7,1,4,39,'D',0),(102,7,1,4,40,'C',1),(103,7,1,4,41,'C',0),(104,7,1,4,42,'C',0),(105,7,1,4,44,'A',1),(106,9,1,4,25,'A',1);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (107,9,1,4,26,'B',0),(108,9,1,4,27,'B',1),(109,9,1,4,28,'B',1),(110,9,1,4,29,'C',1),(111,9,1,4,30,'C',1),(112,9,1,4,31,'A',1),(113,9,1,4,32,'A',1),(114,9,1,4,33,'B',1),(115,9,1,4,34,'A',0),(116,9,1,4,35,'D',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (117,9,1,4,36,'C',1),(118,9,1,4,37,'A',1),(119,9,1,4,38,'A',1),(120,9,1,4,39,'B',1),(121,9,1,4,40,'C',1),(122,9,1,4,41,'C',0),(123,9,1,4,42,'B',1),(124,9,1,4,44,'B',0),(125,5,1,4,25,'A',1),(126,5,1,4,26,'C',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (127,5,1,4,27,'B',1),(128,5,1,4,28,'A',0),(129,5,1,4,29,'B',0),(130,5,1,4,30,'D',0),(131,5,1,4,31,'D',0),(132,5,1,4,32,'A',1),(133,5,1,4,33,'B',1),(134,5,1,4,34,'C',0),(135,5,1,4,35,'B',1),(136,5,1,4,36,'B',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (137,5,1,4,37,'A',1),(138,5,1,4,38,'A',1),(139,5,1,4,39,'D',0),(140,5,1,4,40,'C',1),(141,5,1,4,41,'C',0),(142,5,1,4,42,'A',0),(143,5,1,4,43,'B',0),(144,5,1,4,44,'A',1),(172,3,1,4,25,'A',1),(173,3,1,4,26,'A',1);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (174,3,1,4,27,'D',0),(175,3,1,4,28,'B',1),(176,3,1,4,29,'D',0),(177,3,1,4,30,'C',1),(178,3,1,4,31,'C',0),(179,3,1,4,32,'D',0),(180,3,1,4,33,'A',0),(181,3,1,4,34,'B',1),(182,3,1,4,35,'A',0),(183,3,1,4,36,'B',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (184,3,1,4,37,'A',1),(185,3,1,4,38,'A',1),(186,3,1,4,39,'A',0),(187,3,1,4,40,'C',1),(188,3,1,4,41,'A',1),(189,3,1,4,42,'C',0),(190,3,1,4,43,'C',0),(191,3,1,4,44,'A',1),(192,13,1,4,25,'B',0),(193,13,1,4,26,'A',1);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (194,13,1,4,27,'B',1),(195,13,1,4,28,'B',1),(196,13,1,4,29,'A',0),(197,13,1,4,30,'B',0),(198,13,1,4,31,'A',1),(199,13,1,4,32,'A',1),(200,13,1,4,33,'C',0),(201,13,1,4,34,'B',1),(202,13,1,4,35,'A',0),(203,13,1,4,36,'B',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (204,13,1,4,37,'A',1),(205,13,1,4,38,'A',1),(206,13,1,4,39,'B',1),(207,13,1,4,40,'A',0),(208,13,1,4,41,'A',1),(209,13,1,4,42,'B',1),(210,13,1,4,43,'A',1),(211,13,1,4,44,'B',0),(212,6,1,4,25,'A',1),(213,6,1,4,26,'D',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (214,6,1,4,27,'B',1),(215,6,1,4,28,'A',0),(216,6,1,4,29,'C',1),(217,6,1,4,30,'C',1),(218,6,1,4,31,'B',0),(219,6,1,4,32,'A',1),(220,6,1,4,33,'A',0),(221,6,1,4,34,'C',0),(222,6,1,4,35,'A',0),(223,6,1,4,36,'C',1);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (224,6,1,4,37,'A',1),(225,6,1,4,38,'A',1),(226,6,1,4,39,'A',0),(227,6,1,4,40,'C',1),(228,6,1,4,41,'C',0),(229,6,1,4,42,'B',1),(230,6,1,4,44,'C',0),(250,45,1,5,45,'D',0),(251,45,1,5,46,'B',0),(252,45,1,5,47,'A',1);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (253,45,1,5,49,'C',0),(254,45,1,5,50,'C',1),(255,45,1,5,51,'B',0),(256,45,1,5,52,'A',0),(257,45,1,5,53,'B',1),(258,45,1,5,54,'A',1),(259,45,1,5,55,'B',1),(260,45,1,5,56,'A',1),(261,45,1,5,57,'B',0),(262,45,1,5,58,'A',0);
INSERT INTO `cbt_students_answers`(`student_ans_id`,`student_id`,`subj_id`,`class_id`,`quest_id`,`student_ans`,`remark`) VALUES (263,45,1,5,59,'A',0),(264,45,1,5,60,'B',1),(265,45,1,5,61,'C',1),(266,45,1,5,62,'B',0),(267,45,1,5,63,'D',0),(268,45,1,5,64,'A',1);
UNLOCK TABLES;
ALTER TABLE `cbt_students_answers` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_students_subjects`;
CREATE TABLE IF NOT EXISTS `cbt_students_subjects` (  `student_subj_id` int(11) NOT NULL AUTO_INCREMENT,  `student_id` int(11) NOT NULL,  `subj_id` int(11) NOT NULL,  PRIMARY KEY (`student_subj_id`),  KEY `cand_id` (`student_id`),  KEY `course_id` (`subj_id`),  CONSTRAINT `cbt_students_subjects_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `cbt_students` (`student_id`),  CONSTRAINT `cbt_students_subjects_ibfk_2` FOREIGN KEY (`subj_id`) REFERENCES `cbt_subjects` (`subj_id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_students_subjects` DISABLE KEYS;
LOCK TABLES `cbt_students_subjects` WRITE;
UNLOCK TABLES;
ALTER TABLE `cbt_students_subjects` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_subjects`;
CREATE TABLE IF NOT EXISTS `cbt_subjects` (  `subj_id` int(11) NOT NULL AUTO_INCREMENT,  `subject` varchar(50) NOT NULL,  PRIMARY KEY (`subj_id`),  UNIQUE KEY `course` (`subject`)) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_subjects` DISABLE KEYS;
LOCK TABLES `cbt_subjects` WRITE;
INSERT INTO `cbt_subjects`(`subj_id`,`subject`) VALUES (9,'Basic Science'),(11,'Biology'),(5,'Chemistry'),(10,'Civic Education'),(3,'Computer Studies'),(13,'CRK'),(2,'English Language'),(8,'Further Mathematics'),(6,'Geography'),(4,'Government');
INSERT INTO `cbt_subjects`(`subj_id`,`subject`) VALUES (7,'History'),(12,'IRK'),(1,'Mathematics'),(14,'SOCIAL STUDIES');
UNLOCK TABLES;
ALTER TABLE `cbt_subjects` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_subjs_classes`;
CREATE TABLE IF NOT EXISTS `cbt_subjs_classes` (  `subj_class_id` int(11) NOT NULL AUTO_INCREMENT,  `subj_id` int(11) NOT NULL,  `class_id` int(11) NOT NULL,  `max_time` time DEFAULT NULL,  PRIMARY KEY (`subj_class_id`),  KEY `subj_id` (`subj_id`,`class_id`),  KEY `class_id` (`class_id`),  CONSTRAINT `cbt_subjs_classes_ibfk_1` FOREIGN KEY (`subj_id`) REFERENCES `cbt_subjects` (`subj_id`),  CONSTRAINT `cbt_subjs_classes_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `cbt_classes` (`class_id`)) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_subjs_classes` DISABLE KEYS;
LOCK TABLES `cbt_subjs_classes` WRITE;
INSERT INTO `cbt_subjs_classes`(`subj_class_id`,`subj_id`,`class_id`,`max_time`) VALUES (1,7,4,NULL),(2,7,5,NULL),(3,7,6,NULL),(4,8,4,NULL),(5,8,5,NULL),(6,8,6,NULL),(7,2,1,NULL),(8,2,2,NULL),(9,2,3,NULL),(10,2,4,NULL);
INSERT INTO `cbt_subjs_classes`(`subj_class_id`,`subj_id`,`class_id`,`max_time`) VALUES (11,2,5,NULL),(12,2,6,NULL),(13,5,4,NULL),(14,5,5,NULL),(15,5,6,NULL),(16,1,1,NULL),(17,1,2,NULL),(18,1,3,NULL),(19,1,4,'00:45:00'),(20,1,5,'01:00:00');
INSERT INTO `cbt_subjs_classes`(`subj_class_id`,`subj_id`,`class_id`,`max_time`) VALUES (21,1,6,NULL),(40,3,1,NULL),(41,3,2,NULL),(42,3,3,NULL),(43,3,4,NULL),(44,3,5,NULL),(45,3,6,NULL),(46,6,4,NULL),(47,6,5,NULL),(48,6,6,NULL);
INSERT INTO `cbt_subjs_classes`(`subj_class_id`,`subj_id`,`class_id`,`max_time`) VALUES (49,4,4,NULL),(50,4,5,NULL),(51,4,6,NULL),(52,9,1,NULL),(53,9,2,NULL),(54,9,3,NULL),(55,10,1,NULL),(56,10,2,NULL),(57,10,3,NULL),(58,10,4,NULL);
INSERT INTO `cbt_subjs_classes`(`subj_class_id`,`subj_id`,`class_id`,`max_time`) VALUES (59,10,5,NULL),(60,10,6,NULL),(61,11,4,NULL),(62,11,5,NULL),(63,11,6,NULL),(64,12,1,NULL),(65,12,2,NULL),(66,12,3,NULL),(67,12,4,NULL),(68,12,5,NULL);
INSERT INTO `cbt_subjs_classes`(`subj_class_id`,`subj_id`,`class_id`,`max_time`) VALUES (69,12,6,NULL),(70,13,1,NULL),(71,13,2,NULL),(72,13,3,NULL),(73,13,4,NULL),(74,13,5,NULL),(75,13,6,NULL),(76,14,1,NULL),(77,14,2,NULL),(78,14,3,NULL);
UNLOCK TABLES;
ALTER TABLE `cbt_subjs_classes` ENABLE KEYS;
SET CHARACTER_SET_CLIENT='latin1';
SET CHARACTER_SET_RESULTS='latin1';
SET CHARACTER_SET_CONNECTION='latin1';
SET NAMES 'latin1';
CREATE DATABASE IF NOT EXISTS `computer_based_test` DEFAULT CHARACTER SET latin1;
USE `computer_based_test`;

DROP TABLE IF EXISTS `cbt_users`;
CREATE TABLE IF NOT EXISTS `cbt_users` (  `user_id` int(11) NOT NULL AUTO_INCREMENT,  `username` varchar(40) NOT NULL,  `hashed_password` varchar(40) NOT NULL,  `hint` int(40) NOT NULL,  `date_created` datetime NOT NULL,  `creator_id` int(11) NOT NULL,  PRIMARY KEY (`user_id`),  UNIQUE KEY `username` (`username`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
ALTER TABLE `cbt_users` DISABLE KEYS;
LOCK TABLES `cbt_users` WRITE;
INSERT INTO `cbt_users`(`user_id`,`username`,`hashed_password`,`hint`,`date_created`,`creator_id`) VALUES (1,'admin','dd94709528bb1c83d08f3088d4043f4742891f4f',0,'2016-02-23 14:14:28',1);
UNLOCK TABLES;
ALTER TABLE `cbt_users` ENABLE KEYS;
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
SET SQL_NOTES=@OLD_SQL_NOTES;
SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS;
SET CHARACTER_SET_CONNECTION=@OLD_CHARACTER_SET_CONNECTION;
SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION;
